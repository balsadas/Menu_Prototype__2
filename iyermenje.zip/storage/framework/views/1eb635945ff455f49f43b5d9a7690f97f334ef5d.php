<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('main.create_new_category'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('include.block-header.min', ['data' => ['sub' => trans('main.create_new'), 'title' => trans('main.category')]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <form action="<?php echo e(route('categories.store')); ?>" class="form-contact needs-validation" method="POST" enctype="multipart/form-data" novalidate>
    <?php echo csrf_field(); ?>
    <div class="card card-bordered mb-2">
      <div class="card-inner">
        <h5 class="float-title"><?php echo app('translator')->get('main.name'); ?></h5>
        <div class="row g-4">
          <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
              <div class="form-group">
                <label for="name-<?php echo e($localeCode); ?>" class="form-label"><?php echo e($properties['native']); ?></label>
                <div class="form-control-wrap">
                  <input type="text" id="name-<?php echo e($localeCode); ?>" name="name[<?php echo e($localeCode); ?>]" value="<?php echo e(old('name.' . $localeCode)); ?>"
                         class="form-control form-control-lg <?php $__errorArgs = ['name.' . $localeCode];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="<?php echo e($properties['native']); ?>" required>
                  <?php if($errors->has('name.' . $localeCode)): ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo e($errors->first('name.' . $localeCode)); ?></strong></span>
                  <?php else: ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo app('translator')->get('main.field_required'); ?></strong></span>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
    <div class="row g-4">
      <div class="col-12">
        <label for="file" class="form-label"><?php echo app('translator')->get('main.image'); ?></label>
        <div class="form-control-wrap">
          <input type="file" id="file" name="file" class="form-control form-control-lg <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="<?php echo app('translator')->get('main.choose_image'); ?>" required>
          <?php if($errors->has('file')): ?>
            <span class="invalid-feedback" role="alert"><strong><?php echo e($errors->first('file')); ?></strong></span>
          <?php else: ?>
            <span class="invalid-feedback" role="alert"><strong><?php echo app('translator')->get('main.field_required'); ?></strong></span>
          <?php endif; ?>
        </div>
      </div>

      
      <div style="display:none;" class="col-md-4" id="col-leaf">
        <div class="sp-plan-opt">
          <div class="custom-control custom-switch">
            <input type="checkbox" class="custom-control-input" name="is_leaf" id="is-leaf" value="1" checked>
            <label class="custom-control-label text-soft" for="is-leaf"><?php echo app('translator')->get('main.is_it_leaf_category'); ?></label>
          </div>
        </div>
      </div>
      

      <div class="col-12 <?php echo e(old('parent_id') || old('has_parent') ? '' : 'd-none'); ?>" id="col-category">
        <div class="form-group">
          <label class="form-label" for="category"><span><?php echo app('translator')->get('main.category'); ?></span></label>
          <div class="form-control-wrap">
            <select class="form-select <?php $__errorArgs = ['parent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="category" name="parent_id" data-search="on"
                    data-ui="lg" <?php echo e(old('parent_id') || old('has_parent') ? '' : 'disabled'); ?>>
              <option disabled hidden selected></option>
              <?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($parent->id); ?>" <?php echo e(old('parent_id') == $parent->id ? 'selected' : ''); ?>><?php echo e($parent->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('parent_id')): ?>
              <span class="invalid-feedback" role="alert"><strong><?php echo e($errors->first('parent_id')); ?></strong></span>
            <?php else: ?>
              <span class="invalid-feedback" role="alert"><strong><?php echo app('translator')->get('main.field_required'); ?></strong></span>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <div class="col-12">
        <button class="btn btn-primary"><?php echo app('translator')->get('main.submit'); ?></button>
      </div>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>
      $(function () {
          let col_category = $('#col-category');
          let col_leaf = $('#col-leaf');
          let select = $('#col-category select');
          let checkbox_leaf = $('#col-leaf input');

          $('#has-parent').change(function () {
              if ($(this).is(':checked')) {
                  col_category.removeClass('d-none');
                  col_leaf.addClass('d-none');
                  select.prop('required', true);
                  select.prop('disabled', false);
                  checkbox_leaf.prop('disabled', true);
              } else {
                  col_category.addClass('d-none');
                  col_leaf.removeClass('d-none');
                  select.prop('required', false);
                  select.prop('disabled', true);
                  checkbox_leaf.prop('disabled', false);
              }
          });
      });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pikir\mainRestourantMenu\A_KING_MENU\uc-baha\resources\views/categories/create.blade.php ENDPATH**/ ?>