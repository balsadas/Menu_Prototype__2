<?php if($data['items']->total() > $data['limit']): ?>
  <?php echo e($data['items']->onEachSide(1)->links()); ?>

<?php endif; ?><?php /**PATH /var/www/MADO/resources/views/include/paginate.blade.php ENDPATH**/ ?>