<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('main.ordering_category'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <link href="<?php echo e(asset('css/jquery-ui.min.css')); ?>" rel="stylesheet" type="text/css">
  <style>
    #sortable {
      list-style-type: none;
      margin: 0;
      padding: 0;
      width: 60%;
    }

    #sortable li {
      margin: 0 3px 3px 3px;
      padding: 0.4em 0.4em 0.4em 0;
      float: unset;
      text-align: left;
      cursor: grabbing;
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('include.block-header.min', ['data' => ['sub' => trans('main.ordering'), 'title' => trans('main.category')]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <h5 class="title"><?php echo e(trans('main.ordering_category')); ?></h5>
  <form action="<?php echo e(route('categories.order.update')); ?>" method="post" class="needs-validation mt-4" enctype="multipart/form-data" novalidate>
    <?php echo csrf_field(); ?>
    <?php echo method_field('patch'); ?>
    <ul id="sortable" class="mb-5">
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
          <span class="sort-icon mr-2"><em class="icon ni ni-grid-sq"></em></span>
          <span><?php echo e($category->name); ?></span>
          <input type="hidden" name="order[]" value="<?php echo e($category->id); ?>">
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <button class="btn btn-primary"><?php echo app('translator')->get('main.submit'); ?></button>
  </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>" type="text/javascript"></script>
  <script>
      $(function () {
          let sortable = $("#sortable");

          sortable.sortable();
          sortable.disableSelection();
      });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pikir\hojamyrat_orginal_projects\soltan\soltan-loft-v2\resources\views/categories/order.blade.php ENDPATH**/ ?>