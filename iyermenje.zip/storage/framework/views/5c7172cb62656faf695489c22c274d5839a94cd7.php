<div class="nk-block-head nk-block-head-lg">
  <div class="nk-block-head-sub"><span><?php echo app('translator')->get('main.all'); ?></span></div>
  <div class="nk-block-between-md g-4">
    <div class="nk-block-head-content">
      <h2 class="nk-block-title fw-normal"><?php echo e($data['title']); ?></h2>
    </div>
    <div class="nk-block-head-content">
      <ul class="nk-block-tools gx-3">
        <?php if(Route::is('categories.index') || Route::is('foods.index')): ?>
           <li>
              <a href="<?php echo e($data['route_order']); ?>" class="btn btn-white btn-dim btn-outline-primary">
                <em class="icon ni ni-list"></em><span class="d-none d-sm-inline-block"><?php echo app('translator')->get('main.ordering'); ?></span>
              </a>
            </li>
        <?php endif; ?>
        <li>
          <a href="<?php echo e($data['route']); ?>" class="btn btn-white btn-dim btn-outline-primary">
            <em class="icon ni ni-edit"></em><span class="d-none d-sm-inline-block"><?php echo app('translator')->get('main.create_new'); ?></span>
          </a>
        </li>
      </ul>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\Pikir\mainRestourantMenu\A_KING_MENU\uc-baha\resources\views/include/block-header/index.blade.php ENDPATH**/ ?>