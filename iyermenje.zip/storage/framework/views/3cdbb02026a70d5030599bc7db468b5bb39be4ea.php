<?php if(count($data['foods'])): ?>
  <div class="nk-block">
    <div class="card card-bordered mb-5">
      <table class="table">
        <thead>
        <tr class="tb-tnx-head">
          <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th><?php echo e($properties['native']); ?></th>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <th><?php echo app('translator')->get('main.category'); ?></th>
          <th><?php echo app('translator')->get('main.active'); ?></th>
          
          <th>&nbsp;</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $data['foods']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr class="tb-tnx-item">
            <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <td><?php echo e($food->getTranslation('name', $locale)); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <td><?php echo e($food->category->name); ?></td>
            <td>
              <?php if($food->is_active): ?>
                <span class="text-success"><?php echo app('translator')->get('main.yes'); ?></span>
              <?php else: ?>
                <span class="text-danger"><?php echo app('translator')->get('main.no'); ?></span>
              <?php endif; ?>
            </td>
            
            <td style="padding:0 4px; width:100px;" class="tb-col-action">
              <span class="mr-1"><a href="<?php echo e(route('foods.show', $food->id)); ?>" class="link-cross link-eye mr-sm-n1"><em class="icon ni ni-eye"></em></a></span>
              <span class="mr-1"><a href="<?php echo e(route('foods.edit', $food->id)); ?>" class="link-cross link-edit mr-sm-n1"><em class="icon ni ni-edit-alt"></em></a></span>
              <span><a href="#" onclick="if (confirm('<?php echo e(trans("main.want_to_remove")); ?>')) { document.getElementById('destroy-<?php echo e($food->id); ?>').submit(); }"
                       class="link-cross mr-sm-n1"><em class="icon ni ni-trash"></em></a></span>
              <form action="<?php echo e(route('foods.destroy', $food->id)); ?>" method="post" id="destroy-<?php echo e($food->id); ?>">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <?php echo $__env->make('include.paginate', ['data' => ['items' => $data['foods'], 'limit' => 10]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
<?php else: ?>
  <p><?php echo app('translator')->get('main.no_food'); ?></p>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Pikir\completed project\MADO_ALL\Mado v3\resources\views/include/tables/foods.blade.php ENDPATH**/ ?>