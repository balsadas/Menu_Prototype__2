<?php if(session('success')): ?>
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true"></span>
    </button>
  </div>
<?php endif; ?>

<?php if(session('error')): ?>
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?php echo e(session('error')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true"></span>
    </button>
  </div>
<?php endif; ?>

<?php if(session('warning')): ?>
  <div class="alert alert-warning alert-dismissible fade show" role="alert">
    <?php echo e(session('warning')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true"></span>
    </button>
  </div>
<?php endif; ?>

<?php if(session('danger')): ?>
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?php echo e(session('danger')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true"></span>
    </button>
  </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Pikir\completed project\MADO_ALL\Mado v3\resources\views/include/messages.blade.php ENDPATH**/ ?>