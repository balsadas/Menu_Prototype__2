<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('main.my_profile'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="nk-block-head">
    <div class="nk-block-head-content">
      <div class="nk-block-head-sub"><span><?php echo app('translator')->get('main.view_profile'); ?></span></div>
      <h2 class="nk-block-title fw-normal"><?php echo app('translator')->get('main.my_profile'); ?></h2>
      <div class="nk-block-des">
        <p><?php echo app('translator')->get('main.manage_profile_text'); ?></p>
      </div>
    </div>
  </div>
  <div class="nk-block">
    <div class="card card-bordered">
      <div class="nk-data data-list">
        <div class="data-item" data-toggle="modal" data-target="#profile-edit">
          <div class="data-col">
            <span class="data-label"><?php echo app('translator')->get('main.full_name'); ?></span>
            <span class="data-value"><?php echo e($user->name); ?></span>
          </div>
          <div class="data-col data-col-end"><span class="data-more"><em class="icon ni ni-forward-ios"></em></span></div>
        </div>
        <div class="data-item" data-toggle="modal" data-target="#profile-edit">
          <div class="data-col">
            <span class="data-label"><?php echo app('translator')->get('main.username'); ?></span>
            <span class="data-value"><?php echo e($user->username); ?></span>
          </div>
          <div class="data-col data-col-end"><span class="data-more"><em class="icon ni ni-forward-ios"></em></span></div>
        </div>
        <div class="data-item" data-toggle="modal" data-target="#profile-edit">
          <div class="data-col">
            <span class="data-label"><?php echo app('translator')->get('main.password'); ?></span>
            <span class="data-value text-soft">*****</span>
          </div>
          <div class="data-col data-col-end"><span class="data-more"><em class="icon ni ni-forward-ios"></em></span></div>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade show" tabindex="-1" role="dialog" id="profile-edit">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
      <div class="modal-content">
        <a href="#" class="close" data-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
        <div class="modal-body modal-body-lg">
          <h5 class="title"><?php echo app('translator')->get('main.update_profile'); ?></h5>
          <form action="<?php echo e(route('profile.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
            <div class="row gy-4">
              <div class="col-md-6">
                <div class="form-group">
                  <label class="form-label" for="full-name"><?php echo app('translator')->get('main.full_name'); ?></label>
                  <input type="text" class="form-control form-control-lg <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="full-name" name="name" value="<?php echo e($user->name); ?>"
                         placeholder="<?php echo app('translator')->get('main.enter_full_name'); ?>" required>
                  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label class="form-label" for="username"><?php echo app('translator')->get('main.username'); ?></label>
                  <input type="text" class="form-control form-control-lg <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="username" name="username" value="<?php echo e($user->username); ?>"
                         placeholder="<?php echo app('translator')->get('main.enter_username'); ?>" required>
                  <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label class="form-label" for="password"><?php echo app('translator')->get('main.password'); ?></label>
                  <input type="password" class="form-control form-control-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" name="password"
                         placeholder="<?php echo app('translator')->get('main.new_password'); ?>">
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label class="form-label" for="password_confirmation"><?php echo app('translator')->get('main.password_confirmation'); ?></label>
                  <input type="password" name="password_confirmation" id="password_confirmation"
                         class="form-control form-control-lg <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="<?php echo app('translator')->get('main.repeat_password_confirmation'); ?>">
                  <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="col-12">
                <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                  <li>
                    <button class="btn btn-lg btn-primary"><?php echo app('translator')->get('main.update_profile'); ?></button>
                  </li>
                  <li>
                    <a href="#" data-dismiss="modal" class="link link-light"><?php echo app('translator')->get('main.cancel'); ?></a>
                  </li>
                </ul>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>
      $(function () {
        <?php if($errors->any()): ?>
        $('#profile-edit').modal('show')
        <?php endif; ?>
      })
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/MADO/resources/views/profile.blade.php ENDPATH**/ ?>