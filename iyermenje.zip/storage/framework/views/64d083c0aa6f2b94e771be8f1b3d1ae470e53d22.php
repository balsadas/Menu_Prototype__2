

<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('main.add_food_price'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('include.block-header.min', ['data' => ['sub' => trans('main.add_food_price'), 'title' => $food->name]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <form action="<?php echo e(route('foods.sizes.store', $food->id)); ?>" class="form-contact needs-validation" method="POST" novalidate>
    <?php echo csrf_field(); ?>
    <div class="card card-bordered mb-2">
      <div class="card-inner">
        <h5 class="float-title"><?php echo app('translator')->get('main.name'); ?></h5>
        <div class="row g-4">
          <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
              <div class="form-group">
                <label for="name-<?php echo e($localeCode); ?>" class="form-label"><?php echo e($properties['native']); ?></label>
                <div class="form-control-wrap">
                  <input type="text" id="name-<?php echo e($localeCode); ?>" name="name[<?php echo e($localeCode); ?>]" value="<?php echo e(old('name.' . $localeCode)); ?>"
                         class="form-control form-control-lg <?php $__errorArgs = ['name.' . $localeCode];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="<?php echo e($properties['native']); ?>">
                  <?php if($errors->has('name.' . $localeCode)): ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo e($errors->first('name.' . $localeCode)); ?></strong></span>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>

    <div class="form-group">
      <label for="price" class="form-label"><?php echo app('translator')->get('main.price'); ?></label>
      <div class="form-control-wrap">
        <input type="number" id="price" name="price" class="form-control form-control-lg <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="<?php echo app('translator')->get('main.price'); ?>"
               value="<?php echo e(old('price')); ?>" min="1" step="0.01" required>
        <?php if($errors->has('price')): ?>
          <span class="invalid-feedback" role="alert"><strong><?php echo e($errors->first('price')); ?></strong></span>
        <?php else: ?>
          <span class="invalid-feedback" role="alert"><strong><?php echo app('translator')->get('main.field_required'); ?></strong></span>
        <?php endif; ?>
      </div>
    </div>
    <p class="text-warning">***If food has single size do not type the name fields</p>
    <button class="btn btn-primary"><?php echo app('translator')->get('main.submit'); ?></button>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/MADO/resources/views/foods/size/create.blade.php ENDPATH**/ ?>