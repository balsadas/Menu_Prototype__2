

<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('main.menu'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="image-container flex flex-col justify-between w-full h-full">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.header','data' => []]); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <div  class="flex flex-col items-center w-full scrollbar-hide h-auto mt-[22px] scrollbar-hide overflow-y-auto text-white">
            <div class="relative flex flex-wrap flex-row justify-start mt-1 mx-auto w-[288px] ssm:w-[296px] smd:w-[348px] slg:w-[392px]">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('category',$category->id)); ?>">
                    <div class="relative w-[120px] ssm:w-[124px] smd:w-[150px] slg:w-[172px] h-auto m-[12px] rounded-[4px] overflow-hidden">
                        <div class="sizesOfImages">
                            <img loading="lazy" class="lazyload w-full h-full rounded-[4px]" data-src="<?php echo e($category->getImage()); ?>" alt="category img">
                        </div>
                        <div class="absolute top-0 left-0 z-20 flex flex-col justify-center items-center text-center sizesOfImages text-white">
                            <div class="flex flex-col justify-center items-center">
                                <p class="sizesOfTextContainer normal-case text-[14px] ssm:text-[16px] sm:text-[18px] my-auto -tracking-[0.02em] font-[600px] leading-4 ssm:leading-[18px] smd:leading-[19px]">
                                    <?php echo e($category->name); ?>                                                           
                                </p>
                                <span class="w-[21px] h-[3px] bg-white rounded-[0.5px]"></span>
                            </div>
                            
                        </div>
                        <div style="background: linear-gradient(0deg, rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3));"
                        class="absolute top-0 left-0 z-10 sizesOfImages"></div>
                    </div> 
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 
            </div>
        </div>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.pikir','data' => []]); ?>
<?php $component->withName('pikir'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <div>    

        <div class="hiddenLang justify-center items-center hidden absolute top-0 left-0 w-full h-full bg-[#092b427e] z-20">
            <div class="flex flex-col w-auto h-auto bg-[#1E376C] px-8 ssm:px-6 py-4 z-50 rounded-[4px]">
                
                <div  class="w-full text-right -mt-3 -mr-4 ssm:mr-0">
                    <span onclick="document.querySelector('.hiddenLang').style.display = 'none';" 
                    class="text-[20px] slg:text-[22px] text-white">&times;</span>
                </div>
                <p class="text-white text-center text-[20px] font-[400px] -tracking-[0.02em]"><?php echo e(trans('main.choose_lang')); ?></p>
                <div class="text-[20px] font-[400px] -tracking-[0.02em]">
                    <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a style="border: 1px solid rgba(255, 255, 255, 0.4);" hreflang="<?php echo e($localeCode); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>" 
                        class="TLWstyle bg-[#1B2A50] hover:bg-[#233568c2] text-[16px] ssm:text-[18px]">
                            <?php echo e($properties["native"]); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </div>  
    
            </div>
        </div>


    <script src="<?php echo e(asset('js/lazyload.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/MADO/resources/views/web/home.blade.php ENDPATH**/ ?>