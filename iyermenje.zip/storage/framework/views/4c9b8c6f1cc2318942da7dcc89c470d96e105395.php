<meta charset="UTF-8">
<meta name="author" content="Pikir">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="description" content="Menu for MADO">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"> 

<link rel="shortcut icon" href="<?php echo e(asset('icon/logo.png')); ?>" type="image/x-icon"/>
<link rel="stylesheet" href="<?php echo e(asset('style/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('style/inter.css')); ?>">



<title><?php echo $__env->yieldContent('title'); ?> | MADO</title><?php /**PATH C:\xampp\htdocs\Pikir\completed project\MADO_ALL\Mado v3\resources\views/includes/head.blade.php ENDPATH**/ ?>