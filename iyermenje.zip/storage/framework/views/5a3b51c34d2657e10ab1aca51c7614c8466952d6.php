<div class="nk-block-head nk-block-head-lg">
  <div class="nk-block-head-sub"><span><?php echo e($data['sub']); ?></span></div>
  <div class="nk-block-between-md g-4">
    <div class="nk-block-head-content">
      <h2 class="nk-block-title fw-normal"><?php echo e($data['title']); ?></h2>
    </div>

    <?php echo $__env->yieldContent('button'); ?>

  </div>
</div><?php /**PATH C:\xampp\htdocs\Pikir\completed project\MADO_ALL\Mado v3\resources\views/include/block-header/min.blade.php ENDPATH**/ ?>