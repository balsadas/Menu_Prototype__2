<meta charset="UTF-8">
<meta name="author" content="Pikir">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="description" content="Menu for hezzet">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<link rel="shortcut icon" href="<?php echo e(asset('icon/favicon.ico')); ?>" type="image/x-icon">
<link rel="stylesheet" href="<?php echo e(asset('style/style.css')); ?>">




<title><?php echo $__env->yieldContent('title'); ?> | hezzet</title>
<?php /**PATH C:\xampp\htdocs\Pikir\gurnamalylar\soltan-loft\resources\views/includes/head.blade.php ENDPATH**/ ?>