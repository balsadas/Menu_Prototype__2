<div style="background: var(--low-opacity-opacity-24, rgba(255, 255, 255, 0.24));" class="absolute BackdropFilter bottom-0 left-0 z-50 flex flex-row justify-center items-center h-[48px] w-full">
    <span class="flex justify-center items-center text-[12px] font-[400px] w-[40%] whitespace-nowrap <?php echo e($type); ?>">
        Powered by&nbsp;<a href="http://pikir.biz"> Pikir</a>
    </span>
</div><?php /**PATH C:\xampp\htdocs\Pikir\gurnamalylar\soltan-loft\resources\views/components/pikir.blade.php ENDPATH**/ ?>