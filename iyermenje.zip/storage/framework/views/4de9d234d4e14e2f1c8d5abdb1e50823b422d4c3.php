<?php $__env->startSection('title'); ?> menu <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="relative flex flex-col w-full h-full">
        <div class="w-full h-full flex flex-col justify-center items-center gap-[16px] z-40">
            <div class="flex flex-col justify-center items-center  w-full h-auto">
                <div class="text-[#800080] text-[32px] -tracking-[0.02em] mb-[24px]">
                    <p class="font-bold">MENU</p>
                </div>
                <img class="w-[260px] smd:w-[314px]" src="<?php echo e(asset('icon/logo.png')); ?>" alt="logo">
            </div>

            <div class="ahref">
                <div class="langBg">
                    <div class="flex justify-center items-center w-full h-full">
                        <p class="text-[#800080] font-[500px] text-[18px] -tracking-[0.02em]">Dil saýlaň</p>
                    </div>
                    <div class="flex flex-col gap-[16px]">
                        <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a hreflang="<?php echo e($localeCode); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>/home"
                                class="TLWstyle bg-[#800080] hover:bg-[#500850] text-[#FFFFFF] text-[16px] font-[400px]">
                                <?php echo e($properties["native"]); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.pikir','data' => ['type' => 'text-[#800080]']]); ?>
<?php $component->withName('pikir'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'text-[#800080]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>


    <img class="absolute top-0 right-0" src="<?php echo e(asset('icon/topright.png')); ?>" alt="">
    <img class="absolute bottom-0 left-0" src="<?php echo e(asset('icon/bottomleft.png')); ?>" alt="">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pikir\gurnamalylar\soltan-loft\resources\views/web/welcome.blade.php ENDPATH**/ ?>