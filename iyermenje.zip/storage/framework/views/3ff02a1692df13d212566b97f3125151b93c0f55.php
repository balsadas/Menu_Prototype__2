<div style="background: #1B2A50;" class="relative z-50 flex flex-row justify-center items-center mb-0 -pb-1 h-[20px] ssm:h-[22px] smd:h-[24px] slg:h-[26px] w-full text-[12px] ssm:text-[13px] smd:text-[14px]  px-2">
    <div class="container flex flex-row justify-between items-center w-full h-6">
        <span class="flex justify-center items-center w-[40%] text-[#FFFFFF] whitespace-nowrap">
            &copy; <?php echo e(date('Y')); ?>&nbsp; MADO
        </span>   

        <span class="flex justify-center items-center w-[40%] text-[#FFFFFF] whitespace-nowrap">
            Powered by&nbsp;<a href="http://pikir.biz" class="text-[#FFFFFF]"> Pikir</a>
        </span>
    </div>  
</div><?php /**PATH C:\xampp\htdocs\Pikir\completed project\MADO_ALL\Mado v3\resources\views/components/pikir.blade.php ENDPATH**/ ?>