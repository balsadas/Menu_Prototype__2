<?php 
    $a = 'tm';
    $b = 'ru';
    $c = 'en';
    $d = 'tr';
?>

<div class="flex flex-row text-[12px] ssm:text-[13px] smd:text-[14px] md:text-[16px] text-white uppercase font-semibold z-50">            
        <a href="<?php echo e(LaravelLocalization::getLocalizedURL($a, null, [], true)); ?>"  hreflang="<?php echo e($b); ?>"  class="px-2 border-r-2 border-[#fff] <?php if(LaravelLocalization::getCurrentLocale() == $a ): ?> text-[#F0C272] <?php endif; ?>">
          <?php echo e($a); ?>

        </a>      
        <a href="<?php echo e(LaravelLocalization::getLocalizedURL($b, null, [], true)); ?>"  hreflang="<?php echo e($b); ?>"  class="px-2 border-r-2 border-[#fff] <?php if(LaravelLocalization::getCurrentLocale() == $b ): ?> text-[#F0C272] <?php endif; ?>">
            <?php echo e($b); ?>

        </a>
        <a href="<?php echo e(LaravelLocalization::getLocalizedURL($c, null, [], true)); ?>"  hreflang="<?php echo e($c); ?>"  class="px-2 border-r-2 <?php if(LaravelLocalization::getCurrentLocale() == $c ): ?> text-[#F0C272] <?php endif; ?>">
            <?php echo e($c); ?>

        </a>
        <a href="<?php echo e(LaravelLocalization::getLocalizedURL($d, null, [], true)); ?>"  hreflang="<?php echo e($d); ?>"  class="px-2 <?php if(LaravelLocalization::getCurrentLocale() == $d ): ?> text-[#F0C272] <?php endif; ?>">
            <?php echo e($d); ?>

        </a>
</div>   <?php /**PATH /var/www/MADO/resources/views/includes/chooseLANG.blade.php ENDPATH**/ ?>