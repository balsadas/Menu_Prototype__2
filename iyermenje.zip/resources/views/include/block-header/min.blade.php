<div class="nk-block-head nk-block-head-lg">
  <div class="nk-block-head-sub"><span>{{ $data['sub'] }}</span></div>
  <div class="nk-block-between-md g-4">
    <div class="nk-block-head-content">
      <h2 class="nk-block-title fw-normal">{{ $data['title'] }}</h2>
    </div>

    @yield('button')

  </div>
</div>