<meta charset="UTF-8">
<meta name="author" content="Pikir">
<meta name="csrf-token" content="{{ csrf_token() }}">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="description" content="Menu for hezzet">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<link rel="shortcut icon" href="{{  asset('icon/favicon.ico')}}" type="image/x-icon">
<link rel="stylesheet" href="{{ asset('style/style.css') }}">
{{-- <link rel="stylesheet" href="{{ asset('style/inter.css') }}"> --}}



<title>@yield('title') | hezzet</title>
