<?php

return [
    'empty' => 'success',
    'not_empty' => 'danger',
    'reserved' => 'warning',
];