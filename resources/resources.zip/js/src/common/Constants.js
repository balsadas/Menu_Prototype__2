export default {
  Powered: "Powered by Pikir.",
  appLocales: ["en", "tm", "ru", "tr"],
  storePhones: ["+99365726162", "+99312754844", "+99312754944"],
  phone: "+99364552554",
  currency: "TMT",

  _welcome: "/",
  _catalog: "/catalog",
  _items: "/items",
  inst: "@soltan",
  tik: "@soltan",
  address: "Aşgabat ş.,2127-nji (G.Kulyýew)k.,72 jaý 2-nji gat (obýezdnoý)",

};
